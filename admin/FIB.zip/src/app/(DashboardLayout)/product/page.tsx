"use client";
import { Plus, Edit2, Trash2, Eye } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PaginationControls } from "@/components/shared/PaginationControls";

const subCats: Record<string, string[]> = {
  Export: ["Garments", "Textiles", "Leather Goods", "Jute Products"],
  Import: ["Raw Materials", "Machinery", "Chemicals", "Consumer Goods"],
};

export default function ProductPage() {
  const [category, setCategory] = useState("Export");
  const [subCategory, setSubCategory] = useState("");
  const [query, setQuery] = useState("");

  const handleCategoryChange = (val: string) => {
    setCategory(val);
    setSubCategory("");
  };

  const meta = { total: 20, page: 1, limit: 10, totalPage: 10 }
  
  
  const products = [
    { id: 1, name: "MacBook Pro 16\"", category: "Electronics", price: "$2,499", status: "Active", stock: 15 },
    { id: 2, name: "Office Desk", category: "Furniture", price: "$299", status: "Active", stock: 8 },
    { id: 3, name: "Winter Jacket", category: "Clothing", price: "$129", status: "Active", stock: 42 },
    { id: 4, name: "Wireless Mouse", category: "Electronics", price: "$29", status: "Inactive", stock: 0 },
    { id: 5, name: "Desk Chair", category: "Furniture", price: "$199", status: "Active", stock: 12 },
  ];

  return (
    <div className="space-y-6 pt-5 md:pt-0">
      <div className="flex md:flex-row flex-col md:gap-0 gap-5 md:items-center justify-between">
        <div>
          <h1 className="text-xl md:text-3xl font-bold text-gray-900">Products</h1>
          <p className="text-gray-500 mt-2 text-sm md:text-base">Manage all your products</p>
        </div>
        <Link href="/product/create"
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-white font-semibold transition-all hover:opacity-90"
          style={{ backgroundColor: "#5D4037" }}
        >
          <Plus size={20} />
          Add Product
        </Link>
      </div>

      <div className="relative">
        <div className="flex flex-col gap-3 sm:mb-5 mb-14">
          {/* Search Bar */}
          <Field orientation="horizontal" className="border border-primary/20 rounded-xl px-3 py-1.5 bg-secondary/70">
            <Input
              type="search"
              placeholder="Search products..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="border-none outline-none shadow-none flex-1 text-white placeholder:text-white"
            />

            <div className="flex gap-5 sm:static absolute top-15">
              {/* Category Select */}
              <Select value={category}
                onValueChange={(value) =>
                  handleCategoryChange(value)
                }>
                <SelectTrigger
                  className="flex max-w-32 w-full bg-primary p-2 rounded-lg text-white [&>span]:text-white [&>svg]:text-white border-none"
                >
                  <SelectValue placeholder="Category" />
                </SelectTrigger>

                <SelectContent className="bg-primary rounded-xl text-white">
                  <SelectGroup>
                    <SelectLabel className="text-white">Select Categories</SelectLabel>

                    <SelectItem value="Export" className="rounded-lg">Export</SelectItem>
                    <SelectItem value="Import" className="rounded-lg">Import</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>

              {/* Sub Category Select */}
              <Select value={subCategory} onValueChange={(value) => setSubCategory(value)}>
                <SelectTrigger
                  className="flex max-w-32 w-full bg-primary p-2 rounded-lg text-white [&>span]:text-white [&>svg]:text-white border-none"
                >
                  <SelectValue placeholder="Category" />
                </SelectTrigger>

                <SelectContent className="bg-primary rounded-xl text-white">
                  <SelectGroup>
                    <SelectLabel className="text-white">Select Categories</SelectLabel>

                    {
                      (subCats[category] || []).map((s) => (
                        <SelectItem key={s} value={s} className="rounded-lg">{s}</SelectItem>
                      ))
                    }
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </Field>
        </div>

        {/* table */}
        <div className="rounded-xl border border-primary/20 bg-secondary/50 w-full max-w-full overflow-hidden">
          <div className="overflow-x-auto">
            <Table className="min-w-max text-sm">
              <TableHeader>
                <TableRow className="bg-primary/5 hover:bg-primary/5">
                  <TableHead className="font-semibold text-gray-700">
                    image
                  </TableHead>
                  <TableHead className="font-semibold text-gray-700 text-nowrap">
                    Product Name
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700 text-nowrap">
                    Category
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700 text-nowrap">
                    Sub Category
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700 text-nowrap">
                    Brand
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700">
                    Materials
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700">
                    Color
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700">
                    Size
                  </TableHead>

                  <TableHead className="font-semibold text-gray-700">
                    Gender
                  </TableHead>

                  {
                    category === "Export" && (
                      <>
                        <TableHead className="font-semibold text-gray-700">
                          MOQ
                        </TableHead>
                      </>
                    )
                  }

                  {
                    category === "Import" && (
                      <>
                        <TableHead className="font-semibold text-gray-700">
                          Price
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          discountPrice
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Cost Price
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Stock
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Weight
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Dimensions
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Warranty
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Return Policy
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          status
                        </TableHead>

                        <TableHead className="font-semibold text-gray-700">
                          Featured
                        </TableHead>
                      </>
                    )
                  }

                  <TableHead className="text-right font-semibold text-gray-700">
                    Actions
                  </TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {products.map((product) => (
                  <TableRow
                    key={product.id}
                    className="border-primary/10"
                  >
                    <TableCell className="font-medium text-gray-900">
                      {product.name}
                    </TableCell>

                    <TableCell className="text-gray-600">
                      {product.category}
                    </TableCell>

                    <TableCell className="font-medium text-gray-900">
                      {product.price}
                    </TableCell>

                    <TableCell>
                      <span
                        className={`
                px-3 py-1 rounded-full text-sm font-medium
                ${product.stock > 0
                            ? "bg-green-50 text-green-700"
                            : "bg-red-50 text-red-700"
                          }
              `}
                      >
                        {product.stock}
                      </span>
                    </TableCell>

                    <TableCell>
                      <span
                        className={`
                px-3 py-1 rounded-full text-sm font-medium
                ${product.status === "Active"
                            ? "bg-blue-50 text-blue-700"
                            : "bg-gray-100 text-gray-700"
                          }
              `}
                      >
                        {product.status}
                      </span>
                    </TableCell>

                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 transition-colors">
                          <Eye size={18} />
                        </button>

                        <button className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors">
                          <Edit2 size={18} />
                        </button>

                        <button className="p-2 hover:bg-red-50 rounded-lg text-red-600 transition-colors">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
      <PaginationControls meta={meta}/>
    </div>
  );
}
